import requests

username = 'ACa6391524f9446ada762be1972596ed'
password = 'a54290fc8f9c224466e0180c5e284fd2'

number_to_text = '+918458992112'
twillo_number = '+1302286960931'

msg = 'Hi this Ratnesh \nand this message for testing.'

def xml_pretty(xml_string):
	import xml.dom.minidom
	xml = xml.dom.minidom.parseString(xml_string)
	pretty_xml_ = xml.toprettyxml()
	print(pretty_xml_)

base_url = 'https://api.twilio.com/2010-04-01/Accounts'
msg_url = base_url + '/'+username+'/Messages'

auth = (username,password)

data = {
	"From": twillo_number,
	"To": number_to_text,
	"Body": msg,
	#"MediaUrl":""img,
}

#r = requests.get(base_url, auth=auth)
r = requests.post(msg_url, data=data, auth=auth)

print(r.status_code)
print(xml_pretty(r.text)